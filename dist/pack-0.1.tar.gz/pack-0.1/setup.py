from setuptools import setup

setup(
    name='pack',
    version='0.1',
    description='this first pack',
    url='#',
    author='MrMohammad',
    author_email='dsaidja',
    license='MIT',
    packages=['pack'],
    install_requires=['requests'],
    zip_safe=False
)
