def get_rates():
    print('this first pack')